package application;
	
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import view.Controller;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;


public class SongLib extends Application {
	
	//@FXML private ListView<String> SongList;
	/*
	@FXML private ListCell<String> ArtistL;
	@FXML private ListCell<String> SongL;
	*/
	//For Table SongDescr
	//@FXML private ListView<String> SongDetail;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			/*
			BorderPane root = new BorderPane();
			
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			*/
			
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/view/M player 1.fxml"));
			
			Pane root = (Pane)loader.load();
			Scene scene = new Scene(root);
			
			Controller C = loader.getController();
			C.start(primaryStage);
			
			primaryStage.setScene(scene);
			primaryStage.setTitle("My Mp3 Player");
			primaryStage.setResizable(false);  
			primaryStage.show();
	
			
			/*
			SongList
			.getSelectionModel()
			.selectedIndexProperty()
			.addListener(
			(obs,oldVal,newVal)->
			
			Controller.PromptDelete(primaryStage));
			*/
			
			
			
			
			
			
		} catch(Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
