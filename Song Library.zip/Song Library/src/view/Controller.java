package view;

import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

//For Lists..
import java.util.*;

public class Controller {
	
	//List of Strings which can only be accessed by the controller class and cannot be overrided
	//private static LinkedList<String[]> L = new LinkedList<String[]>();
	//private static Hashtable<String[],int[]> H = new Hashtable<String[],int[]>();
	
	
	private static TreeMap<Integer,String> TH = new TreeMap<Integer,String>();

	//Design
	
	/*
	@FXML Button Add;
	@FXML Button c2f;
	@FXML TextField f;
	@FXML TextField c;

	public void convert(ActionEvent e) {
		Button b = (Button)e.getSource();
		if (b == f2c) {
			//float fval = Float.valueOf(f.getText());
			//float cval = (fval-32)*5/9;
			//c.setText(String.format("%5.1f", cval));
		
		
		} else {
			//float cval = Float.valueOf(c.getText());
			//float fval = cval*9/5+32;
			//f.setText(String.format("%5.1f", fval));
			System.out.println("BUTTON: ADD[0] USED");
		
		
		}
	}
	*/
	
	//For Table SongList
	
	@FXML private ListView<String> SongList;
	@FXML private ListCell<String> ArtistL;
	@FXML private ListCell<String> SongL;
	
	//For Table SongDescr
	@FXML private ListView<String> SongDetail;
	@FXML private ListCell<String> ArtistL2;
	@FXML private ListCell<String> SongL2;
	@FXML private ListCell<String> AlbumL;
	@FXML private ListCell<String> YearL;
	

	//For Add
	@FXML TextField Song;
	@FXML TextField Artist;
	@FXML TextField Album;
	@FXML TextField Year;
	@FXML Button AddButton;
	
	//For Delete
	@FXML TextField Song1;
	@FXML TextField Artist1;
	@FXML TextField Album1;
	@FXML TextField Year1;
	@FXML Button DeleteButton;
	
	//For Edit
	@FXML TextField Song11;
	@FXML TextField Artist11;
	@FXML TextField Album11;
	@FXML TextField Year11;
	@FXML TextField Song111;
	@FXML TextField Artist111;
	@FXML TextField Album111;
	@FXML TextField Year111;
	@FXML Button EditButton;
	
	
	public void convert(ActionEvent e) {
		Button b = (Button)e.getSource();
		
		if (b == AddButton) {
			//float fval = Float.valueOf(f.getText());
			//float cval = (fval-32)*5/9;
			//c.setText(String.format("%5.1f", cval));
			
			System.out.println("ADD BUTTON USED");
			
			String [] SAAY  =new String[4];
			
			SAAY[0] = Song.getText();
			SAAY[1] = Artist.getText();
			
			if(SAAY[0].length()==0||SAAY[1].length()==0) {
				System.out.println("Must enter valid song and artist");
				return;
			}
			
			SAAY[2] = Album.getText();
			SAAY[3]= Year.getText();
		
			//LinkedList<String[]> L2 = new LinkedList<String[]>();
			
			//L2.add(SAAY);
			

			String Saay = SAAY[0]+"-"+SAAY[1]+"-"+SAAY[2]+"-"+SAAY[3];
			
			int Key = Saay.hashCode()<0? Saay.hashCode()*-1:Saay.hashCode();
			
			if(Key<0)
				Key*=-1;
			
			//Integer G = new Integer(Key);
			
			if(TH.containsKey(Key)) {
				//ERROR CASE WHERE SONG TO ADD ALREADY EXISTS
				System.out.println("Error, Song already added");
				//CREATE WINDOW HERE
				
				
				
				//System.exit(-1);
				//
				return;
			}
			//HANDLE ADDING SONG
			//HASH BY song name + artist name
		
			//Integer G 
			int x = Saay.hashCode()<0? Saay.hashCode()*-1:Saay.hashCode();
			
			if(x<0){
				x*=-1;
			}
			
			System.out.printf("Putting in Treemap Bucket: %d\n",x);
			
			TH.put(x, Saay);
			
			AddRow(Saay);
			
		} else if (b == DeleteButton) {
			//float fval = Float.valueOf(f.getText());
			//float cval = (fval-32)*5/9;
			//c.setText(String.format("%5.1f", cval));
			
			System.out.println("DELETE BUTTON USED");
			
			
			String [] SAAY  =new String[4];
			
			SAAY[0] = Song1.getText();
			SAAY[1] = Artist1.getText();
			
			if(SAAY[0].length()==0||SAAY[1].length()==0) {
				System.out.println("Must enter valid song and artist");
				return;
			}
			
			
			SAAY[2] = Album1.getText();
			SAAY[3]= Year1.getText();
			
			String Saay = SAAY[0]+"-"+SAAY[1]+"-"+SAAY[2]+"-"+SAAY[3];
			
			//HANDLE REMOVING SONG
			int Key = Saay.hashCode()<0? Saay.hashCode()*-1:Saay.hashCode();//(SAAY[0].hashCode() <0? SAAY[0].hashCode()*-1:SAAY[0].hashCode()) + (SAAY[1].hashCode()<0? SAAY[1].hashCode()*-1:SAAY[1].hashCode());
			if(Key<0)
				Key*=-1;
			
			if(TH.containsKey(Key)) {
			TH.remove(Key);
			DeleteRow(Saay);
			}
			
		} else if (b == EditButton) {
			//float fval = Float.valueOf(f.getText());
			//float cval = (fval-32)*5/9;
			//c.setText(String.format("%5.1f", cval));
			
			System.out.println("EDIT BUTTON USED");
			
			String [] SAAY  =new String[4];
			
			SAAY[0] = Song11.getText();
			SAAY[1] = Artist11.getText();
			
			if(SAAY[0].length()==0||SAAY[1].length()==0) {
				System.out.println("Must enter valid song and artist");
				return;
			}
			
			SAAY[2] = Album11.getText();
			SAAY[3]= Year11.getText();
		
			String Saay = SAAY[0]+"-"+SAAY[1]+"-"+SAAY[2]+"-"+SAAY[3];
			
			int Key = Saay.hashCode()<0? Saay.hashCode()*-1:Saay.hashCode();
			
			if(Key<0)
				Key*=-1;
			
			//HANDLE Editing SONG
			if(TH.containsKey(Key)) {
			TH.remove(Key);
			DeleteRow(Saay);
			}
			else {
				
				System.out.println("No Entry To Edit");
				return;
			}
			
			SAAY[0] = Song111.getText();
			SAAY[1] = Artist111.getText();
		
			//CHECK IF THESE TWO ARE EMPTY
			if(SAAY[0].length()==0||SAAY[1].length()==0) {
				System.out.println("Must enter valid song and artist");
				return;
			}
			
			SAAY[2] = Album111.getText();
			SAAY[3]= Year111.getText();
			
			//String Saay = SAAY[0]+"-"+SAAY[1]+"-"+SAAY[2]+"-"+SAAY[3];
			
			int G =  Saay.hashCode()<0? Saay.hashCode()*-1:Saay.hashCode();
			
			if(G<0)
				G*=-1;
			
			System.out.printf("Putting in Treemap Bucket: %d\n",G);
			
			TH.put(G, Saay);
			
			AddRow(Saay);
			
		}
		else {
			//float cval = Float.valueOf(c.getText());
			//float fval = cval*9/5+32;
			//f.setText(String.format("%5.1f", fval));
			System.out.println("UNKNOWN BUTTON USED");
			System.exit(-2);
	
		}
		
		//Print List of Song,Artist,Album,Year, SAAY!
		PrintTreeMap();
	}
	private void PrintTreeMap() {
		
		System.out.println("Song List\n");
		
		Set<?> set = TH.entrySet();
		
		Iterator<?> i = set.iterator();
		
		while(i.hasNext()) {
			Map.Entry<Integer,String> me = (HashMap.Entry<Integer,String>)i.next();
			System.out.print(me.getKey() + ": ");;
			//nt h =0;
			//while(h<4) {
			
			//tableView.
			System.out.printf("%s",me.getValue());
			
		
			
			//}
		}
		
	}
	
	private String Get(int V) {
		
		System.out.println("Song List\n");
		
		Set<?> set = TH.entrySet();
		
		Iterator<?> i = set.iterator();
		
		while(i.hasNext()) {
			Map.Entry<Integer,String> me = (HashMap.Entry<Integer,String>)i.next();
			System.out.print(me.getKey() + ": ");;
			//nt h =0;
			//while(h<4) {
			
			//tableView.
			System.out.printf("%s",(Object)me.getValue());
			int HC =/*(me.getValue()[0].hashCode()<0? me.getValue()[0].hashCode()*-1:me.getValue()[0].hashCode()) + 
					(me.getValue()[1].hashCode()<0? me.getValue()[1].hashCode()*-1:me.getValue()[1].hashCode())// + 
					//(me.getValue()[2].hashCode()<0? me.getValue()[2].hashCode()*-1:me.getValue()[2].hashCode())+
					/*(me.getValue()[3].hashCode()<0? me.getValue()[3].hashCode()*-1:me.getValue()[3].hashCode())*/ me.getValue().hashCode()<0? me.getValue().hashCode()*-1:me.getValue().hashCode();
			
			System.out.printf("%d COMPARED TO: %d\n", HC,V);
			
			if(HC == V) {
				System.out.println("FOUND KEY");
				/*String[] All = new String[5];//me.getValue();
				
				All[0] = me.getValue()[0];
				All[1] = me.getValue()[1];
				All[2] = me.getValue()[2];
				All[3] = me.getValue()[3];
				All[4] = me.getKey().toString();
				*/
				
				
				//All[4] = me.getKey().toString();
				return me.getValue();
			}
		
			
			//}
		}
		
		return null;
	}
	//Add New Row to Table
	
	private void AddRow(String S) {
		
		ObservableList<String> SL = SongList.getItems();
		ObservableList<String> SD = SongDetail.getItems();
		
		if(SL==null || SD==null) {
			
			System.exit(-3);
		}
		
		//SL.add
		
		
		//SL.add(S[0]+"-"+S[1]+"-"+S[2]+"-"+S[3]);
		//SD.add(S[0]+"-"+S[1]+"-"+S[2]+"-"+S[3]);
		
		//SortedList<String> SortL = new SortedList<String>(SL);
		//SortedList<String> SortD = new SortedList<String>(SD);
		
		String A1 = Get(S.hashCode()<0 ? S.hashCode()*-1:S.hashCode());
		
		if(A1==null) {
			System.out.println("No Value Found");
			return;
		}
		
		//int idx = Integer.parseInt(A1[4]);
		
		//SongList.getItems().add(idx,S[0]+"-"+S[1]+"-"+S[2]+"-"+S[3]);
		//SongList.getItems().addAll(
		
		//));
		// c = GET()
		
		//SongList.getItems().addAll("");
		SongList.getItems().add(A1);
		//SongList.getItems().sort((a,b)-> Integer.compareUnsigned(a.hashCode()<0 ? a.hashCode()*-1:a.hashCode(),b.hashCode()<0 ? b.hashCode()*-1:b.hashCode()));
		SongList.getItems().sort((b,a)-> StrCmp(a,b)/*Integer.compare(a.hashCode(),b.hashCode()*/);
		
		
		
		SongDetail.getItems().add(A1);
		//SongDetail.getItems().sort((a,b)-> Integer.compareUnsigned(a.hashCode()<0 ? a.hashCode()*-1:a.hashCode(), b.hashCode()<0 ? b.hashCode()*-1:b.hashCode()));
		SongDetail.getItems().sort((b,a)-> StrCmp(a,b)/*Integer.compare(a.hashCode(),b.hashCode()*/);
		
		
		//SongList.setItems(SortL);
		//SongDetail.setItems(SortD);
	
		SortedList<String> sortedListL = new SortedList<String>(SL);
        sortedListL.setComparator(new Comparator<String>(){
            @Override
            public int compare(String arg0, String arg1) {
                return arg0.compareToIgnoreCase(arg1);
            }
        });
        
        SortedList<String> sortedListD = new SortedList<String>(SD);
        sortedListD.setComparator(new Comparator<String>(){
            @Override
            public int compare(String arg0, String arg1) {
                return arg0.compareToIgnoreCase(arg1);
            }
        });
		
		//SongList.getItems().add(S[0]+"-"+S[1]/* + "-" + S[2] + "-" + S[3]*/);
		//SongDetail.getItems().add(/*S[0]+"-"+S[1] + "-" + */S[2] + "-" + S[3]);
		
	
		
	}
	
	private int StrCmp(String a, String b) {
		if(a.length()>b.length()) {
			return -1;
		}
		else if(b.length()>a.length()) {
			return 1;
		}
		int i=0;
		char c = a.charAt(i);
		char d = b.charAt(i);
		
		while(i<a.length() && i<b.length()) {
			c = a.charAt(i);
			d = b.charAt(i);
			if(c==d) {
				i++;
				continue;
			}
			else if(c<d) {
				return 1;
			}
			else if(c>d) {
				return -1;
			}
			
			i++;
		}
		
		return 0;
	}
	
	//Delete Row From Table
	private void DeleteRow(String S) {
		SongList.getItems().remove(S);
		SongList.refresh();
		
		SongDetail.getItems().remove(S);
		SongDetail.refresh();
	}
	
	
	
	
	/*
	private void PrintList() {
		int i=0;
		int j=0;
		for(i=0;i<L.size();i++) {
			for(j=0;j<L.get(i).length;j++) {
			System.out.printf("%s,%s,%s,%s",L.get(i)[0],L.get(i)[1],L.get(i)[2],L.get(i)[3]);	
			}
			System.out.println();
		}
		
		
	}
	*/
	static <K,V extends Comparable<? super V>>
	SortedSet<Map.Entry<K,V>> entriesSortedByValues(Map<K,V> map) {
	    SortedSet<Map.Entry<K,V>> sortedEntries = new TreeSet<Map.Entry<K,V>>(
	        new Comparator<Map.Entry<K,V>>() {
	            @Override public int compare(Map.Entry<K,V> e1, Map.Entry<K,V> e2) {
	         
	            	int res = e1.getValue().compareTo(e2.getValue());
	         
	                return res != 0 ? res : 1;
	            }
	        }
	    );
	    sortedEntries.addAll(map.entrySet());
	    return sortedEntries;
	}
	
}
