package view;

import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

//For Lists..
import java.util.*;

public class Controller {
	//For Table SongList
	public int ACase = -1;
	
	public int DCase = -1;
	
	public int ECase = -1;
	public String[] ES = new String[8];
	
	public int PCase = -1;
	
	private String [] NextUp = new String[2];
	
	private LinkedList<String[]> LL = new LinkedList<String[]>();
	
	@FXML
	private DController DC;
	
	@FXML
	private PController PC;
	
	@FXML
	private EController EC;
	
	@FXML private ListView<String> SongList;
	
	//For Table SongDescr
	@FXML private ListView<String> SongDetail;
	
	private Stage St;
	//For Add
	@FXML TextField Song;
	@FXML TextField Artist;
	@FXML TextField Album;
	@FXML TextField Year;
	@FXML Button AddButton;
	
	//Delete Link
	@FXML Button DeleteButton;
	
	//Edit Link
	@FXML Button EditButton;

	
	
	public void start(Stage mainStage) {
		
	St = mainStage;
		
	//SongList.getSelectionModel().select(0);	
		
	/*
	SongList.getSelectionModel().selectedIndexProperty().addListener((obs,oldVal,newVal)->Prompt());
	
	SongList.getSelectionModel().clearSelection();
	
	//SongDetail.getSelectionModel().select(0);	
	
	SongDetail.getSelectionModel().selectedIndexProperty().addListener((obs,oldVal,newVal)->Prompt());

	SongDetail.getSelectionModel().clearSelection();
	*/
	
	SongList.getSelectionModel().getSelectedItems().addListener(new ListChangeListener<String>() {
        public void onChanged(ListChangeListener.Change<? extends String> c) {
        
        if(c==null) {
        	return;
        }
        if(c.getList().size()==0) {
        	return;
        }
        int i=0;
        System.out.printf("\n\nLISTENED TO:\n");
        while(i<c.getList().size()) {
        	System.out.printf("%s --\n %s\n",c.getList().get(i),LL.get(i)[1]);
        	i++;
        }
        i = 0;
        while(i<LL.size()) {
        	if(StrCmp(LL.get(i)[0],c.getList().get(0))==0) {
        		   ES[4] = Split(LL.get(i)[1],'\n',1);
        		   //System.out.println(LL.get(i)[1].substring(ES[4].length(),LL.get(i)[1].length()));
        	       ES[5] = Split(LL.get(i)[1].substring(ES[4].length()+1,LL.get(i)[1].length()),'\n',1);
        	       //System.out.println(LL.get(i)[1].substring(ES[5].length()+ES[4].length(),LL.get(i)[1].length()));
        	       ES[6] = Split(LL.get(i)[1].substring(2+ES[5].length()+ES[4].length(),LL.get(i)[1].length()),'\n',1);
        	       //System.out.println(LL.get(i)[1].substring(ES[6].length()+ES[4].length()+ES[5].length(),LL.get(i)[1].length()));
        	       ES[7] = Split(LL.get(i)[1].substring(3+ES[6].length()+ES[4].length()+ES[5].length(),LL.get(i)[1].length()),'\n',1);
        
        		break;
        	}
        	i++;
        }
        
       
       System.out.printf("\nSuccessful SPLIT: [%s],[%s],[%s],[%s]\n",ES[4],ES[5],ES[6],ES[7]);
       
       SongDetail.getItems().clear();
       SongDetail.getItems().add(ES[4]+"\n"+ES[5]+"\n"+ES[6]+"\n"+ES[7]);
       SongDetail.getSelectionModel().select(SongDetail.getItems().indexOf(ES[4]+"\n"+ES[5]+"\n"+ES[6]+"\n"+ES[7]));
		
       
        }
        
    });
	
	
	SongList.refresh();
	SongDetail.refresh();
	
	SongList.getSelectionModel().clearSelection();
	
	
	SongDetail.getSelectionModel().getSelectedItems().addListener(new ListChangeListener<String>() {
        public void onChanged(ListChangeListener.Change<? extends String> c) {
      
        	System.out.println("Song Detail Clicked");
        	
        	
        }
        }
	);
	//SongDetail.getSelectionModel().clearSelection();
	//SongDetail.getSelectionModel().select(0);
	
	
	}
	
	public void convert(ActionEvent e) {
		
		Button b = (Button)e.getSource();

		System.out.printf("Button:%s Detected",b.toString());
		
		if (b == AddButton) {
			try {
			if(Song.getText().length()==0||Artist.getText().length()==0){
				System.out.println("\nMust enter valid song and artist");
				
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.initOwner(St);
				alert.setTitle("Error, must enter valid song and artist");
				alert.setHeaderText("Invalid Entry");
				alert.showAndWait();
				
				return;
			}	
			AddPrompt();
			if(ACase==0) {
			String [] SAAY  =new String[4];
			//try {
			SAAY[0] = Song.getText();
			SAAY[1] = Artist.getText();
		
			SAAY[2] = Album.getText();
			SAAY[3]= Year.getText();
		
			AddRow(SAAY);
			}
			}
			catch(Exception E) {
				E.printStackTrace();
			}
			ACase = -1;
		}
		
		else if (b == DeleteButton) {
			
			System.out.println("DELETE BUTTON USED");
			if(SongDetail.getItems().size()<=0) {
				System.out.println("No songs to delete");
				
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.initOwner(St);
				alert.setTitle("Error, no songs to delete");
				alert.setHeaderText("Invalid Entry");
				alert.showAndWait();
				
				return;
			}
			
			String S = SongDetail.getItems().get(0);
	
			try {
			DeletePrompt();
			if(DCase==0) {
			System.out.println("ATTEMPTING TO DELETE ROW");
			DeleteRow(S);
			}
			}
			catch(Exception R) {
				R.getStackTrace();
			}
			
			DCase = -1;
			PCase = -1;
			
		} else if (b == EditButton) {
			if(SongList.getItems().size()<=0) {
				System.out.println("\nNo Songs To Edit");
				
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.initOwner(St);
				alert.setTitle("Error, no songs to edit");
				alert.setHeaderText("Invalid Entry");
				alert.showAndWait();
				
				return;
				
			}
			
			EditPrompt();
			if(ECase==0) {
				//Edit Time
				if(SongList.getItems().size()==0) {
					System.out.println("No Songs To Edit");
					
					ECase = -1;
					PCase = -1;
					return;
					
				}
				if(ES[0] == null || ES[1] == null||ES[4]==null||ES[5] == null) {
					System.out.println("Must Select Item to Edit!");
					ECase = -1;
					PCase = -1;
					return;
				}
				if(ES[0].length()==0||ES[1].length()==0||ES[4].length()==0||ES[5].length()==0) {
					System.out.println("Must Enter Valid Edit Entry");
					
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.initOwner(St);
						alert.setTitle("Error, must enter valid edit entry");
						alert.setHeaderText("Invalid Entry");
						alert.showAndWait();
						
					
					ECase = -1;
					PCase = -1;
					return;
				}
				
				String[] S = new String[8];
				S[0] = ES[0].toString();
				S[1] = ES[1].toString();
				S[2] = ES[2].toString();
				S[3] = ES[3].toString();
				
				S[4] = ES[4].toString();
				S[5] = ES[5].toString();
				S[6] = ES[6].toString();
				S[7] = ES[7].toString();
				
				if(SongList.getItems().contains(S[0]+"\n"+S[1])) {
					System.out.println("ALREADY IN SONGLIST");
					/*
					if(S.length>4) {
					System.out.println("Restored Data");
					String [] S2 = new String[4]; 
					S2[0] = S[4]; S2[1] = S[5]; S2[2] = S[6]; S2[3] = S[7];
					AddRow(S2);
					return;
					}
					*/
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.initOwner(St);
					alert.setTitle("Error, entry is already in the song list");
					alert.setHeaderText("Invalid Entry");
					alert.showAndWait();
					
					ECase = -1;
					PCase = -1;
					
					return;	
				}
				
				if(DeleteRow(ES[4]+"\n"+ES[5]+"\n"+ES[6]+"\n"+ES[7]+"\n")>0) {
				
				
				
				AddRow(S);
				}
			}
			ECase = -1;
			PCase = -1;
		}
		
		else {
			//float cval = Float.valueOf(c.getText());
			//float fval = cval*9/5+32;
			//f.setText(String.format("%5.1f", fval));
			System.out.println("UNKNOWN BUTTON USED");
			System.exit(-2);
		}
		
	}

	//Add New Row to Table
	
	private void AddRow(String[] S) {
		
		System.out.println(S);
		
		
		
		ObservableList<String> SL = SongList.getItems();
		ObservableList<String> SD = SongDetail.getItems();
		
		if(SL==null || SD==null) {
			
			System.exit(-3);
		}
		
		SongList.getItems().add(S[0]+"\n"+S[1]);
		SongList.getItems().sort((b,a)-> StrCmp(a,b));
		
		SongDetail.getItems().clear();
		SongDetail.getItems().add(S[0]+"\n"+S[1]+"\n"+S[2]+"\n"+S[3]);
		
        SongList.refresh();
        
        NextUp[0] = S[0]+"\n"+S[1];
        NextUp[1] = S[0]+"\n"+S[1]+"\n"+S[2]+"\n"+S[3];
        
        LL.add(NextUp.clone());
        LL.sort(((b,a)->StrCmp(a[0],b[0])));
	
		SongDetail.refresh();
		
		SongList.getSelectionModel().select(SongList.getItems().indexOf(S[0]+"\n"+S[1]));
		SongDetail.getSelectionModel().select(SongDetail.getItems().indexOf(S[0]+"\n"+S[1]+"\n"+S[2]+"\n"+S[3]));
		
		//ES[4] = S[0]; ES[5] = S[1]; ES[6]=S[2]; ES[7] = S[3];
		
	}
	
	private int StrCmp(String a, String b) {
		
		int DCount = 0;
	
		int i=0;
		char c = a.charAt(i);
		char d = b.charAt(i);
		
		while(i<a.length() && i<b.length() && DCount<2) {
			c = a.charAt(i);
			d = b.charAt(i);
			if(c=='\n' && d=='\n')
				DCount++;
			if(c==d) {
				i++;
				continue;
			}
			else if(c<d) {
				return 1;
			}
			else if(c>d) {
				return -1;
			}
			
			i++;
		}
		
		return 0;
	}
	
	private String Split(String s,char sp,int count) {
		int i=0;
		int c = 0;
		String h = "";
		char[] T = s.toCharArray();
		
		while(i<T.length && c < count ) {
			System.out.printf("%c\n", T[i]);
			if(T[i]==sp) {
				c++;
				i++;
				continue;
			}
			h+=T[i];
			i++;
		}
		
		//System.out.printf("SPLIT STR:%s",h);
		
		return h;
	}
	
	//Delete Row From Table
	private int DeleteRow(String S) {
		if(S==null) {
			System.out.println("NO STRING");
			SongList.getSelectionModel().clearSelection();
			SongDetail.getSelectionModel().clearSelection();
			
			return 0;
		}
		
		if(S.length()==0) {
		System.out.println("NO LENGTH");
		SongList.getSelectionModel().clearSelection();
		SongDetail.getSelectionModel().clearSelection();
		
		return 0;
		}
		
		
		if(ES[4] != null && ES[5] !=null && ES[6] !=null && ES[7] !=null) {
			if(SongDetail.getItems().size()>0) {
				
				System.out.printf(" IF %s!=%s",ES[4]+"\n"+ES[5]+"\n"+ES[6]+"\n"+ES[7]+"\n",SongDetail.getItems().get(0) );
				if(StrCmp((ES[4]+"\n"+ES[5]+"\n"+ES[6]+"\n"+ES[7]+"\n"),SongDetail.getItems().get(0))!=0) {
				int g = SongList.getItems().indexOf(ES[4]+"\n"+ES[5]);
			if(g<0||g>=LL.size()) {
				SongList.getSelectionModel().clearSelection();
				SongDetail.getSelectionModel().clearSelection();
				return 1;
			}
			LL.remove(LL.get(g));
			SongList.getItems().remove(g);
			System.out.println("Removed Exclusive Item From Songlist");
			SongList.getSelectionModel().clearSelection();
			SongDetail.getSelectionModel().clearSelection();
			
			return 0;
				}
			}
		}
		
		
		DCase = -1;
		System.out.printf("DELETE STRING: %s\n\n", S);
		
		String Sp1 = Split(S,'\n',1);
		String Sp2 = Split(S.substring(Sp1.length()+1,S.length()),'\n',1);
		
		int NextIndex = 0;
		int I = SongList.getItems().indexOf(Sp1+"\n"+Sp2);
		if(I==SongList.getItems().size()-1) {
			NextIndex = I-1;
			if(NextIndex<0) {
				//Done
				System.out.println("DONE111");
				
				SongList.getItems().remove(0);
				SongDetail.getItems().remove(0);
				LL.remove(LL.get(0));
				
				SongList.getSelectionModel().clearSelection();
				SongDetail.getSelectionModel().clearSelection();
				
				
				NextUp[0] = "";
				NextUp[1] = "";
				return 1;
			}
		}
		else {
			//Next Song will take place of removed index
			NextIndex = I;
		}
		
		System.out.printf("Next Index determined:%d:::",NextIndex);
		
		if(NextIndex<0) {
			//Done
			System.out.println("DONE222");
			
			SongList.getItems().remove(0);
			SongDetail.getItems().remove(0);
			LL.remove(LL.get(0));
			
			NextUp[0] = SongList.getItems().get(0);
			NextUp[1] = LL.get(0)[1];
			
			SongList.getSelectionModel().clearSelection();
			SongDetail.getSelectionModel().clearSelection();
			
			return 1;
		}
		
		SongList.getItems().remove(Sp1+"\n"+Sp2);
		SongDetail.getItems().remove(S);
		if(I>=0)
		LL.remove(I);
		
		System.out.printf("%s\n", SongList.getItems().get(NextIndex));
		SongDetail.getItems().add(LL.get(NextIndex)[1]);
		NextUp[0] = (LL.get(NextIndex)[0]);
		//NextUp[1] = Split(S.substring(1+NextUp[0].length(), S.length()),'\n',1);
		NextUp[1] = (LL.get(NextIndex)[1]);
		System.out.printf("NEXT UP:: {%s,%s}", NextUp[0],NextUp[1]);
		
		SongList.getSelectionModel().clearSelection();
		SongDetail.getSelectionModel().clearSelection();
		
		SongList.getSelectionModel().select(SongList.getItems().indexOf(NextUp[0]));
		SongDetail.getSelectionModel().select(SongDetail.getItems().indexOf(NextUp[1]));
		//return 1;
		
		
		/*
		ES[0]=null;
		ES[1] = null;
		ES[2] = null;
		ES[3] = null;
		ES[4]=null;
		ES[5] = null;
		ES[6] = null;
		ES[7] = null;
		*/
		return 1;
	}

	//Menu for item clicked
	//Menu 0 - go to options menu delete or edit,
	//Button goes to delete item or edit item menu
	
	//Menu 1 - Delete item - Grabs immediate info from SongListDetails
	
	//Menu 2 - Edit item - Grabs immediate info from SongLost
	private void Prompt() {
		// TODO Auto-generated method stub
		
		if(PCase>=0) {
			return;
		}
		
		try {
			
		//Stage S = null;
		
		//getClass().	
			
		FXMLLoader loader = new FXMLLoader();
		
		System.out.printf("THIS CLASS: %s",getClass().getName());
		
		loader.setLocation(getClass().getResource("/view/M player DeleteOrEdit Popup.fxml"));
		
		Pane root = (Pane)loader.load();
		
		Scene scene = new Scene(root);
		
		Stage S = new Stage();
		
		PController controller = loader.<PController>getController();		
		controller.setParentController(this);
		
		
		S.initOwner(St);
		//S.initModality(Modelity.NONE);
		S.setTitle("Delete/Edit");
		S.setScene(scene);
		S.show();
		}
		catch(Exception e){
			e.printStackTrace();
			System.exit(-1);
		}
		
	}
	public void AddPrompt() {
		// TODO Auto-generated method stub
		
		try {
			
		//Stage S = null;
		
		FXMLLoader loader = new FXMLLoader();
		
		System.out.printf("THIS CLASS: %s",getClass().getName());
		
		loader.setLocation(getClass().getResource("/view/M player Add Popup.fxml"));
		
		Pane root = (Pane)loader.load();
		Scene scene = new Scene(root);
		
		Stage S = new Stage();
		
		AController controller = loader.<AController>getController();		
		controller.setParentController(this);
		
		//S.initModality(Modality.APPLICATION_MODAL);
		
		S.initOwner(St);
		S.setTitle("Add");
		S.setScene(scene);
		S.showAndWait();	
		}
		catch(Exception e){
			e.printStackTrace();
			System.exit(-1);
		}
		
	}
	public void DeletePrompt() {
		// TODO Auto-generated method stub
		
		try {
			
		//Stage S = null;
		
		FXMLLoader loader = new FXMLLoader();
		
		System.out.printf("THIS CLASS: %s",getClass().getName());
		
		loader.setLocation(getClass().getResource("/view/M player Delete Popup.fxml"));
		
		Pane root = (Pane)loader.load();
		Scene scene = new Scene(root);
		
		Stage S = new Stage();
		
		DController controller = loader.<DController>getController();		
		controller.setParentController(this);
		
		//S.initModality(Modality.APPLICATION_MODAL);
		
		S.initOwner(St);
		S.setTitle("Delete");
		S.setScene(scene);
		S.showAndWait();	
		}
		catch(Exception e){
			e.printStackTrace();
			System.exit(-1);
		}
		
	}
	public void EditPrompt() {
		// TODO Auto-generated method stub
		
		try {
			
		//Stage S = null;
		
		FXMLLoader loader = new FXMLLoader();
		
		System.out.printf("THIS CLASS: %s",getClass().getName());
		
		loader.setLocation(getClass().getResource("/view/M player Edit Popup.fxml"));
		
		Pane root = (Pane)loader.load();
		Scene scene = new Scene(root);
		Stage S = new Stage();
		
		EController controller = loader.<EController>getController();		
		controller.setParentController(this);
		
		//S.initModality(Modality.APPLICATION_MODAL);
		S.initOwner(St);
		S.setTitle("Edit");
		S.setScene(scene);
		S.showAndWait();
		
		}
		catch(Exception e){
			e.printStackTrace();
			System.exit(-1);
		}
		
	}
}
