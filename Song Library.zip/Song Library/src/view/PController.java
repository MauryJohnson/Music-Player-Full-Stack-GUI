package view;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class PController {
	//Delete/Edit Prompt
	@FXML Button PromptCancel;
	@FXML Button PromptDelete;
	@FXML Button PromptEdit;

	private Controller ParentController= null;
	/*
	public PController(Controller C) {
		
		this.ParentController = C;
		
	}
	*/
	public void initialize() {
		System.out.println("Dual Prompt controller launched!");
		/*
		if(ParentController==null) {
			System.out.println("Error, No Parent Controller for child window!");
			System.exit(-3);
		}
		*/
		PromptDelete.setOnAction(event -> {
			//if(ParentController.PCase==-1) {
            System.out.println("You clicked Delete...");
            
           
            Stage stage = (Stage)PromptDelete.getScene().getWindow();
            
            if(ParentController.PCase<0) { 
            ParentController.DeletePrompt();
            ParentController.PCase = 0;
            }
           
            stage.hide();
            //stage.close();
			

        });
		
		PromptEdit.setOnAction(event -> {
            System.out.println("You clicked Edit..."); 
            Stage stage = (Stage)PromptEdit.getScene().getWindow();
            
            if(ParentController.PCase<0) {
            ParentController.PCase = 1;
            ParentController.EditPrompt();
            }
            
            stage.hide();
            //stage.close();
            
        });
        
        PromptCancel.setOnAction(event -> {
            System.out.println("You clicked Cancel");
            PromptCancel.getScene().getWindow().hide();
            ParentController.PCase = 2;
        });
		
	}
	
	public void setParentController(Controller parentController) {
		ParentController = parentController;
	}
	
}
