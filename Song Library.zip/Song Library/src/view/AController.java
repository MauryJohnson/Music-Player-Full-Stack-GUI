package view;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

//Add Controller

public class AController {

		//Delete Prompt
		@FXML Button AddAdd;
		@FXML Button AddCancel;
		
		private Controller ParentController = null;
		/*
		public DController(Controller C) {
			
			this.ParentController = C;
			
		}
		*/
		
	public void initialize() {
		System.out.println("Add controller launched!");
		
		/*
		if(ParentController==null) {
			System.out.println("Error, No Parent Controller for child window!");
			System.exit(-3);
		}
		*/
		AddAdd.setOnAction(event -> {
            System.out.println("You clicked Add...");
            ParentController.ACase = 0;
            Stage stage = (Stage)AddAdd.getScene().getWindow(); 
            
            //ParentController.SongList.getSelectionModel().clearSelection();
    		//ParentController.SongDetail.getSelectionModel().clearSelection();
    		/*if(ParentController.DCase<0)
            ParentController.DeleteRow(ParentController.NextUp[1]);
            */
            stage.hide();
            //stage.close();
        });
        
        AddCancel.setOnAction(event -> {
            System.out.println("You clicked Cancel");
            ParentController.ACase = 1;
            Stage stage = (Stage)AddCancel.getScene().getWindow();
            stage.hide();
            //stage.close();
        });
		
	}

	public void setParentController(Controller parentController) {
		ParentController = parentController;
	}
}
