package view;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class DController {

		//Delete Prompt
		@FXML Button DeleteDelete;
		@FXML Button DeleteCancel;
		
		private Controller ParentController = null;
		/*
		public DController(Controller C) {
			
			this.ParentController = C;
			
		}
		*/
		
	public void initialize() {
		System.out.println("Delete controller launched!");
		
		/*
		if(ParentController==null) {
			System.out.println("Error, No Parent Controller for child window!");
			System.exit(-3);
		}
		*/
		DeleteDelete.setOnAction(event -> {
            System.out.println("You clicked Delete...");
            ParentController.DCase = 0;
            Stage stage = (Stage)DeleteDelete.getScene().getWindow(); 
            
            //ParentController.SongList.getSelectionModel().clearSelection();
    		//ParentController.SongDetail.getSelectionModel().clearSelection();
    		/*if(ParentController.DCase<0)
            ParentController.DeleteRow(ParentController.NextUp[1]);
            */
            stage.hide();
            //stage.close();
        });
        
        DeleteCancel.setOnAction(event -> {
            System.out.println("You clicked Cancel");
            ParentController.DCase = 1;
            Stage stage = (Stage)DeleteCancel.getScene().getWindow();
            stage.hide();
            //stage.close();
        });
		
	}

	public void setParentController(Controller parentController) {
		ParentController = parentController;
	}
}
