package view;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class EController {

	//Edit Prompt
		@FXML Button EditCancel;
		@FXML Button EditEdit;
		
		@FXML TextField EditSong;
		@FXML TextField EditArtist;
		@FXML TextField EditAlbum;
		@FXML TextField EditYear;	
		
		private Controller ParentController= null;
		/*
		public EController(Controller C) {
			
			this.ParentController = C;
			
		}
		*/
		public void initialize() {
			
			//WAIT();
			
			System.out.println("Edit controller launched!");
			
			EditEdit.setOnAction(event -> {
	            System.out.println("You clicked Edit...");
	            EditEdit.getScene().getWindow().hide();
	            System.out.printf("%s\n%s\n%s\n%s\n", EditSong.getText(),EditArtist.getText(),EditAlbum.getText(),EditYear.getText());
	            ParentController.ECase = 0;
	            ParentController.ES[0] = EditSong.getText();
	            ParentController.ES[1] = EditArtist.getText();
	            ParentController.ES[2] = EditAlbum.getText();
	            ParentController.ES[3] = EditYear.getText();
	        });
	        
	        EditCancel.setOnAction(event -> {
	            System.out.println("You clicked Cancel");
	            ParentController.ECase = 1;
	            EditCancel.getScene().getWindow().hide();
	        });
			
		}
		
		public void setParentController(Controller parentController) {
			ParentController = parentController;
		}
		
		
}
